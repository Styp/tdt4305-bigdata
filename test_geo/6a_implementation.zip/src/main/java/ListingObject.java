import com.vividsolutions.jts.geom.Point;

/**
 * Created by martin on 20.03.17.
 */
public class ListingObject {
    public String id;
    public String city;
    public Point point;

    @Override
    public String toString() {
        return "ListingObject{" +
                "id='" + id + '\'' +
                ", city='" + city + '\'' +
                ", point=" + point +
                '}';
    }
}
