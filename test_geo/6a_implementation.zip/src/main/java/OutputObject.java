/**
 * Created by martin on 20.03.17.
 */
public class OutputObject {
    public String listingId;
    public String neighbourhood;
    public String city;

    public String toCSV(){
        return listingId + "," + neighbourhood + "," + city + "\n";
    }



    @Override
    public String toString() {
        return "OutputObject{" +
                "listingId='" + listingId + '\'' +
                ", neighbourhood='" + neighbourhood + '\'' +
                ", city='" + city + '\'' +
                '}';
    }
}
