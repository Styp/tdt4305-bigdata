import com.vividsolutions.jts.geom.MultiPolygon;
import com.vividsolutions.jts.geom.Polygon;

/**
 * Created by martin on 20.03.17.
 */
public class Entry {

    public String neighbourhoodName;
    public MultiPolygon multiPolygon;

    @Override
    public String toString() {
        return "Entry{" +
                "neighbourhoodName='" + neighbourhoodName + '\'' +
                ", polygon=" + multiPolygon +
                '}';
    }
}
