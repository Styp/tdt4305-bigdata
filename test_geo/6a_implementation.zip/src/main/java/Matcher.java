import com.github.filosganga.geogson.gson.GeometryAdapterFactory;
import com.github.filosganga.geogson.jts.JtsAdapterFactory;
import com.github.filosganga.geogson.model.FeatureCollection;
import com.google.common.base.Charsets;
import com.google.common.io.Files;
import com.google.gson.*;
import com.google.protobuf.ByteString;
import com.vividsolutions.jts.geom.*;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Created by martin on 20.03.17.
 */
public class Matcher {

    public static void main(String[] args) throws IOException {

        ArrayList<Entry> neighbourhoodList = createNeighbourhoodList("neighbourhoods.geojson");
        ArrayList<ListingObject> listingList = createListingList("listings_us.csv");

        List<OutputObject> outputList = listingList.parallelStream().map((o) -> matchListingToNeighbourhood(o, neighbourhoodList)).collect(Collectors.toList());

        File outputFile = new File("output.txt");
        Files.write("", outputFile, Charsets.UTF_8);
        for (OutputObject o : outputList) {
            System.out.println(o);
            Files.append(o.toCSV(), outputFile, Charsets.UTF_8);
        }

        System.out.println("Matches: " + outputList.size());
    }

    public static OutputObject matchListingToNeighbourhood(ListingObject listingObject, ArrayList<Entry> neighbourhoodList){
        OutputObject o = new OutputObject();
        o.city = listingObject.city;
        o.listingId = listingObject.id;
        o.neighbourhood = "";

        for (Entry e : neighbourhoodList){
            if(e.multiPolygon.contains(listingObject.point)){
                o.neighbourhood = e.neighbourhoodName;
                return o;
            }
        }
        return o;
    }

    public static ArrayList<ListingObject> createListingList(String fileName) throws IOException{
        String content = Files.toString(new File("listings_us.csv"), Charsets.UTF_8);

        ArrayList<ListingObject> entrys = new ArrayList();

        GeometryFactory gf=new GeometryFactory();

        String[] lineString = content.split("\n");
        for (String s : lineString){
            ListingObject l = new ListingObject();
            String[] entryString = s.split("\t");

            l.id = entryString[43];
            l.city = entryString[15];

            try{
                l.point = gf.createPoint(new Coordinate((double) Double.parseDouble(entryString[54]), (double) Double.parseDouble(entryString[51])));
            } catch (NumberFormatException e){
                System.out.println("Error: " + l.id);
            }

            entrys.add(l);
       }
        return entrys;
    }

    public static ArrayList<Entry> createNeighbourhoodList(String fileName) throws IOException {

        String content = Files.toString(new File(fileName), Charsets.UTF_8);

        JsonElement jelement = new JsonParser().parse(content);
        JsonObject jobject = jelement.getAsJsonObject();
        JsonArray features = jobject.getAsJsonArray("features");


        Gson gson = new GsonBuilder()
                .registerTypeAdapterFactory(new JtsAdapterFactory())
                .registerTypeAdapterFactory(new GeometryAdapterFactory())
                .create();

        ArrayList<Entry> entrys = new ArrayList();

        for (JsonElement feature : features){
            Entry e = new Entry();
            e.neighbourhoodName = feature.getAsJsonObject().getAsJsonObject("properties").getAsJsonPrimitive("neighbourhood").toString();

            String multiPolygon = feature.getAsJsonObject().getAsJsonObject("geometry").toString();
            e.multiPolygon = gson.fromJson(multiPolygon, MultiPolygon.class);

            entrys.add(e);
        }

        return entrys;
    }
}
